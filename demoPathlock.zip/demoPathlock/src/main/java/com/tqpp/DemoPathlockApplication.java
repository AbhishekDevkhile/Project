package com.tqpp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPathlockApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPathlockApplication.class, args);
	}

}
