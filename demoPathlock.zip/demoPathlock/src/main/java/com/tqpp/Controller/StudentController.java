
package com.tqpp.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.tqpp.Dao.StudentDao;
import com.tqpp.Model.Student;
import com.tqpp.service.StudentService;




@RestController
public class StudentController
{
	@Autowired
	private StudentService studservice;
	
	@GetMapping("/students")
	public List<Student> getAllStudents()
	{
		return studservice.getAllStudents();	
	}
	
	@PostMapping("/students")
	public ResponseEntity<Void> addstudent(@RequestBody Student s1)
	{
		this.studservice.insertStudent(s1);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	/*
	@GetMapping("/students/{id}")
	public ResponseEntity<Student> getStudent(@PathVariable ("id") int sid) 
	{
		//return  sdao.findById(sid).orElse(new Student());
		
		                    // or
		//using Optional class obj. check data present or not
		 
		Optional<Student> o= sdao.findById(sid);
		if(o.isPresent())
			return new ResponseEntity<Student>(o.get(),HttpStatus.OK);
		else
			return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
		
	} 
	*/
	
	
	                            //OR :=not use by optional class
     //Display database data using postman
    @GetMapping("/students/{id}")
	public Student getStudent(@PathVariable("id") int sid)
	{
		return studservice.getStudentById(sid);	
	}
		
	
	//Delete
	@DeleteMapping("/students/{id}")
	public ResponseEntity<Void> deleteStudent(@PathVariable("id") int sid)
	{
		try
		{
			studservice.deleteStudentById(sid);
		    return new ResponseEntity<Void>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		
		
	}
	
	
	//Create custom method in StudentDao interface 
	@GetMapping("/students/city/{city}")
	public List<Student> getByCity(@PathVariable("city")String city)
	{
		return studservice.findByCity(city);
		
	}
	

	//custom method---->
		 @GetMapping("/students/percent/{percent}")
		 public List<Student> getByPercent(@PathVariable("percent") int percent)
		 {
			 return studservice.findByPercent(percent);
		 }
		 
		//custom method---->
	//     @GetMapping("/student/percent/{percent}")
		 @GetMapping("/students/sortpercent")
		 public List<Student> SortByPercent()
		 {
			 return studservice.sortByPercent();
		 }
		 

		    //custom method---->
			 @GetMapping("/studentss/percent/{percent}")
			 public List<Student> getByPercentGreaterThanEqual(@PathVariable("percent") int percent)
			 {
				 return studservice.findByPercentGreaterThanEqual(percent);
			 }
			 
    
}
