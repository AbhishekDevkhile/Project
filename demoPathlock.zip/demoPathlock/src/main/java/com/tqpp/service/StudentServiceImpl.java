package com.tqpp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tqpp.Dao.StudentDao;
import com.tqpp.Model.Student;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentDao sdao;

	@Override
	public void insertStudent(Student s) {
		sdao.save(s);
		
	}
	
	@Override
	public void deleteStudentById(int id) {
		
		sdao.deleteById(id);
	}

	@Override
	public void updateStudent(Student s) {
		
		sdao.save(s);
	}

	@Override
	public List<Student> getAllStudents() {
		
		return sdao.findAll();
	}

	@Override
	public Student getStudentById(int id) {
		
		return  sdao.getById(id);
	}

	@Override
	public List<Student> findByCity(String city) {
		// TODO Auto-generated method stub
		return sdao.findByCity(city);
	}

	@Override
	public List<Student> findByPercent(int percent) {
		// TODO Auto-generated method stub
		return sdao.findByPercent(percent);
	}

	@Override
	public List<Student> findByPercentLessThan(int percent) {
		// TODO Auto-generated method stub
		return sdao.findByPercentLessThan(percent);
	}

	@Override
	public List<Student> findByPercentGreaterThanEqual(int percent) {
		// TODO Auto-generated method stub
		return sdao.findByPercentGreaterThanEqual(percent);
	}

	@Override
	public List<Student> findByCityAndPercent(String city, int percent) {
		// TODO Auto-generated method stub
		return sdao.findByCityAndPercent(city, percent);
	}

	@Override
	public List<Student> sortByPercent() {
		// TODO Auto-generated method stub
		return sdao.sortByPercent();
	}
	

}
