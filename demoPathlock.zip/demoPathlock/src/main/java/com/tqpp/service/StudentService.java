package com.tqpp.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.tqpp.Model.Student;

public interface StudentService {
	
	    void insertStudent(Student s);
		
	    void deleteStudentById(int id);
		
		void updateStudent(Student s);
		
	    List<Student>getAllStudents();
	    
	    Student getStudentById(int id);
	    
	    public List<Student> findByCity(String city); 
		public List<Student> findByPercent(int percent);
		public List<Student> findByPercentLessThan(int percent);
		public List<Student> findByPercentGreaterThanEqual(int percent);
		public List<Student> findByCityAndPercent(String city, int percent);
		
		// Custom Query---->
		@Query("from Student s order by s.percent desc")
		public List<Student> sortByPercent();

		


}
