package com.tqpp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPathlockMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
