package com.tqpp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPathlockMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPathlockMvcApplication.class, args);
	}

}
