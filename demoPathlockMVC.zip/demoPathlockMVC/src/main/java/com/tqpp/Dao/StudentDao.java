package com.tqpp.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tqpp.Model.Student;

public interface StudentDao extends JpaRepository<Student, Integer>
{
	
	
}
