package com.tqpp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tqpp.Dao.StudentDao;
import com.tqpp.Model.Student;
@Controller
public class StudentController
{
	@Autowired
	private StudentDao sdao;
	
	//data sending to jsp page(view.jsp)
	@GetMapping("/student")
	public ModelAndView m1()
	{
		List<Student>lst=sdao.findAll();
		ModelAndView mv=new ModelAndView("view");
		mv.addObject("studlist",lst);
		return mv;
		
	}

}
